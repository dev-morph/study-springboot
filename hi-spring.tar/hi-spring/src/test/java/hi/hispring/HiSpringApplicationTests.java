package hi.hispring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
